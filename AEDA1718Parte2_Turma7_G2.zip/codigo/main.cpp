/*
 * main.cpp
 *
 */

#include "menu.h"
#include "Functions.h"

int main(){
	menu();
	return 0;
}

