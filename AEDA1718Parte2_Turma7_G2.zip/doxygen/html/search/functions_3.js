var searchData=
[
  ['event',['Event',['../classEvent.html#a5a40dd4708297f7031e29b39e039ae10',1,'Event::Event()'],['../classEvent.html#a2fb2bff37e364023fe54d0f86e49e696',1,'Event::Event(std::vector&lt; Associate *&gt; event_request, std::vector&lt; Associate *&gt; event_organizers, std::string date, std::string local, std::string theme, int phase, Association *association)']]]
];
