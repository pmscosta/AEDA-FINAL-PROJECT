var searchData=
[
  ['mail',['Mail',['../classMail.html',1,'']]]
];
