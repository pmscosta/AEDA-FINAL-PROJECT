var searchData=
[
  ['currentyear',['currentYear',['../classAssociation.html#a38c0785b12a067ee6c295a2d3ee453da',1,'Association']]]
];
