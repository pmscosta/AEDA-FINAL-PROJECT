var searchData=
[
  ['given_5fsupport',['given_support',['../classConference.html#a800a31bff9c492bc417cf8cecf450195',1,'Conference::given_support()'],['../classSummerSchool.html#a7e6899945d6a486e9d1d1f581236630b',1,'SummerSchool::given_support()']]]
];
