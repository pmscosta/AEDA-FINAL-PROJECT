var searchData=
[
  ['subarea',['SubArea',['../classSubArea.html',1,'']]],
  ['summerschool',['SummerSchool',['../classSummerSchool.html',1,'']]]
];
