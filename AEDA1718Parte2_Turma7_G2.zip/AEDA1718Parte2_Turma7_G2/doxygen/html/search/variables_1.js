var searchData=
[
  ['body',['body',['../classMail.html#aaa91a94ee92b2712218a9cae389554f7',1,'Mail']]]
];
