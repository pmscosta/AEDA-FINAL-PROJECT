var classNoSupportGiven =
[
    [ "NoSupportGiven", "classNoSupportGiven.html#a85c20af147aefa12cfa30903d6b6b499", null ],
    [ "getLate", "classNoSupportGiven.html#a44a7843aed1c26053e622cd3666080e0", null ],
    [ "getTotal", "classNoSupportGiven.html#a2888ed870de8146fc4ee15c84edf5530", null ],
    [ "late", "classNoSupportGiven.html#a4f1413a35ad22fe50bc1d5dc08414784", null ],
    [ "total", "classNoSupportGiven.html#ab70919acf20a32d05a2b6b4d8753dcb5", null ]
];