var Network_8cpp =
[
    [ "cmpDate", "Network_8cpp.html#a980b011e0dcc77bbab3fcde4c16a861c", null ],
    [ "cmpTitle", "Network_8cpp.html#a7390ef66aec2a001c967143a66786fb3", null ]
];