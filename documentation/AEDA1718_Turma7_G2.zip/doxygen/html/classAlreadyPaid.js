var classAlreadyPaid =
[
    [ "AlreadyPaid", "classAlreadyPaid.html#afa3ccdeb73e3570b346a4938a836a44e", null ],
    [ "getID", "classAlreadyPaid.html#a54d1869f925f98bb8621131debf5f2c8", null ],
    [ "getYear", "classAlreadyPaid.html#a9bc932f3c57052ce0508abc48b5a5a6c", null ],
    [ "uniqueID", "classAlreadyPaid.html#ad5c108176759cfd9d2f9ca2dd143d843", null ],
    [ "year", "classAlreadyPaid.html#aca0124c0c69671e1452020fc8697c3ca", null ]
];