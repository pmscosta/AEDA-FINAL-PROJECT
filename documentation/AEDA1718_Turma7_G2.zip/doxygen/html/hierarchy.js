var hierarchy =
[
    [ "AlreadyPaid", "classAlreadyPaid.html", null ],
    [ "Area", "classArea.html", null ],
    [ "Associate", "classAssociate.html", null ],
    [ "Association", "classAssociation.html", null ],
    [ "Event", "classEvent.html", [
      [ "Conference", "classConference.html", null ],
      [ "SummerSchool", "classSummerSchool.html", null ]
    ] ],
    [ "Mail", "classMail.html", null ],
    [ "Network", "classNetwork.html", null ],
    [ "NoSuchDate", "classNoSuchDate.html", null ],
    [ "NoSuchID", "classNoSuchID.html", null ],
    [ "NoSupportGiven", "classNoSupportGiven.html", null ],
    [ "NotEnoughMoney", "classNotEnoughMoney.html", null ],
    [ "NotUpToDate", "classNotUpToDate.html", null ],
    [ "SubArea", "classSubArea.html", null ],
    [ "Trainer", "classTrainer.html", null ]
];