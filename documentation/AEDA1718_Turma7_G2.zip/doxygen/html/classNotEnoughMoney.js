var classNotEnoughMoney =
[
    [ "NotEnoughMoney", "classNotEnoughMoney.html#a8d626cbca191437e4c16f3d058a7d204", null ],
    [ "getID", "classNotEnoughMoney.html#a7f6054f81a4a84f1e9f2cb3f24fc498b", null ],
    [ "uniqueID", "classNotEnoughMoney.html#a448ce0cf6fa4322dca36d379c3b94028", null ]
];