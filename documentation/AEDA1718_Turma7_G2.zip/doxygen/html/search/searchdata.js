var indexSectionsWithContent =
{
  0: "abcdefgilmnoprstuvy~",
  1: "acemnst",
  2: "acefmns",
  3: "acdegilmnoprstuv~",
  4: "abcdefgilmnprstuy"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables"
};

