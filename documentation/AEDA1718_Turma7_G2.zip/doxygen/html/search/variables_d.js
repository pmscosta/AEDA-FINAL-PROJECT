var searchData=
[
  ['status',['status',['../classAssociate.html#aacf79a4e389c7db3d8636b788cb2089f',1,'Associate']]],
  ['subareas',['subareas',['../classArea.html#af5eafd40b41ae847a009feef631ce07f',1,'Area']]]
];
