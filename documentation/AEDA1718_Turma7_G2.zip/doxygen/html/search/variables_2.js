var searchData=
[
  ['currentyear',['currentYear',['../classAssociation.html#a22ed128174ec5fd440f8373fe47f42da',1,'Association']]]
];
