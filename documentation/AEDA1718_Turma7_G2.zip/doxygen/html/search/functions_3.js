var searchData=
[
  ['event',['Event',['../classEvent.html#a5a40dd4708297f7031e29b39e039ae10',1,'Event::Event()'],['../classEvent.html#af5dc5a200023c83243ab755e69eb4827',1,'Event::Event(std::vector&lt; Associate *&gt; event_request, std::vector&lt; Associate *&gt; event_organizers, std::string date, std::string local, std::string theme, Association *association)']]]
];
