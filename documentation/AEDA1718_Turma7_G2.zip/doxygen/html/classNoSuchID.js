var classNoSuchID =
[
    [ "NoSuchID", "classNoSuchID.html#a3b85ef775a99d9f93eabaa21ef29e950", null ],
    [ "getID", "classNoSuchID.html#a42be677d2a3bbf7c12feffeda0904bfa", null ],
    [ "ID", "classNoSuchID.html#a1b0c95e546b2147a298230f33d3dbeec", null ]
];