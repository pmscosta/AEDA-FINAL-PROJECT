var classSummerSchool =
[
    [ "SummerSchool", "classSummerSchool.html#af66df445834a36ccb6e67d5503c1b776", null ],
    [ "SummerSchool", "classSummerSchool.html#a4fa81719de6c453629fd522530cbb911", null ],
    [ "SummerSchool", "classSummerSchool.html#a556427f09423c48d5b81c77d99f5e73f", null ],
    [ "~SummerSchool", "classSummerSchool.html#ad3c3df760cfaee1042fe5290fa487b2c", null ],
    [ "getEstimative", "classSummerSchool.html#a019b9e38108b7dd31cd93cab285d0d00", null ],
    [ "getSupport", "classSummerSchool.html#a86f34a2f39dcd33171e77c386165219c", null ],
    [ "getTrainers", "classSummerSchool.html#aba18410ee9fbafd26858232104b5b39f", null ],
    [ "getType", "classSummerSchool.html#a2ba547411ca8f161c2c579f9f55f913e", null ],
    [ "showInfo", "classSummerSchool.html#a61ac7307840f787e3de639d431248e26", null ],
    [ "given_support", "classSummerSchool.html#a7e6899945d6a486e9d1d1f581236630b", null ],
    [ "trainers", "classSummerSchool.html#a3208a977c13ce8d7415b179a040efae3", null ],
    [ "type", "classSummerSchool.html#a4bce94c462b492844cacce921427d212", null ]
];