var classSubArea =
[
    [ "SubArea", "classSubArea.html#a9649b113a07cc887aec5bdf83b75666c", null ],
    [ "SubArea", "classSubArea.html#a27e357e4c5765eb3128fdde5cdf690e3", null ],
    [ "~SubArea", "classSubArea.html#a0423d8d6d9f297cc1ceff557279d9be8", null ],
    [ "getInitials", "classSubArea.html#a0385787547e85f2481bc0031e6c98f10", null ],
    [ "getName", "classSubArea.html#a8370d762b413cb20c233cf0ca56315da", null ],
    [ "initials", "classSubArea.html#a3e0a456f5ce325e2a778a17d1929b5d0", null ],
    [ "name", "classSubArea.html#aa1b0997da15caea7144ae73963da9f82", null ]
];