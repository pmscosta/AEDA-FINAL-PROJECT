var classTrainer =
[
    [ "Trainer", "classTrainer.html#ae033382eaedd47966c8667439376369a", null ],
    [ "~Trainer", "classTrainer.html#aa3d993d1eb090f4111e12a710fe9d3f6", null ],
    [ "getInstitution", "classTrainer.html#a92ce4244bea56ae32c0ba33fdd959667", null ],
    [ "getName", "classTrainer.html#a4bf23e8eaefc7c2f400b4ba14f2e1c69", null ],
    [ "institution", "classTrainer.html#ae895aa7f146d8bf271399215d4ede36b", null ],
    [ "name", "classTrainer.html#a6b58d4cfdb8d3482cb2c09dd366a6350", null ]
];