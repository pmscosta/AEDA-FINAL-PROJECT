var classMail =
[
    [ "Mail", "classMail.html#acd3d916cd6a769cdaf6e91dbc2c85699", null ],
    [ "Mail", "classMail.html#a5801c10c9e03a2ea2f0def9f5a957e18", null ],
    [ "~Mail", "classMail.html#a7f59d642ff71033500e1fac06ce9b3b1", null ],
    [ "getAuthor", "classMail.html#a23db9880d8a7d0fed31668b895fc3899", null ],
    [ "getBody", "classMail.html#af89b1b3d0f3c9d92a272c06f18fbdec3", null ],
    [ "getDate", "classMail.html#ac45841e601864ec3f84566c3ee77de9a", null ],
    [ "getTitle", "classMail.html#aa51a6657dd3e594e8638ac4486660675", null ],
    [ "setAuthor", "classMail.html#acec00cbed8830746de97efeca4561dd8", null ],
    [ "setBody", "classMail.html#a85ddf08af27648cc0835d66bd6b08dde", null ],
    [ "setDate", "classMail.html#ac5c8d190278b895b2de786be431b0a30", null ],
    [ "setTitle", "classMail.html#aa57f6b5a2f81ded349476984c361275b", null ],
    [ "author", "classMail.html#acfe110a866f8cc54120d4f4ab0f8321b", null ],
    [ "body", "classMail.html#aaa91a94ee92b2712218a9cae389554f7", null ],
    [ "date", "classMail.html#aee9bc87682f6173b92bf135397f38162", null ],
    [ "title", "classMail.html#a2f54f71a529dec6345d84ae60562b207", null ]
];