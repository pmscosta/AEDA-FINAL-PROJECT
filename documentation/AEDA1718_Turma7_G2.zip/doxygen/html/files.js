var files =
[
    [ "Area.cpp", "Area_8cpp.html", null ],
    [ "Area.h", "Area_8h.html", [
      [ "Area", "classArea.html", "classArea" ]
    ] ],
    [ "Associate.cpp", "Associate_8cpp.html", null ],
    [ "Associate.h", "Associate_8h.html", [
      [ "NotUpToDate", "classNotUpToDate.html", "classNotUpToDate" ],
      [ "NotEnoughMoney", "classNotEnoughMoney.html", "classNotEnoughMoney" ],
      [ "AlreadyPaid", "classAlreadyPaid.html", "classAlreadyPaid" ],
      [ "Associate", "classAssociate.html", "classAssociate" ]
    ] ],
    [ "Association.cpp", "Association_8cpp.html", "Association_8cpp" ],
    [ "Association.h", "Association_8h.html", "Association_8h" ],
    [ "Conference.cpp", "Conference_8cpp.html", null ],
    [ "Conference.h", "Conference_8h.html", [
      [ "Conference", "classConference.html", "classConference" ]
    ] ],
    [ "Event.cpp", "Event_8cpp.html", null ],
    [ "Event.h", "Event_8h.html", [
      [ "NoSupportGiven", "classNoSupportGiven.html", "classNoSupportGiven" ],
      [ "Event", "classEvent.html", "classEvent" ]
    ] ],
    [ "Functions.cpp", "Functions_8cpp.html", "Functions_8cpp" ],
    [ "Functions.h", "Functions_8h.html", "Functions_8h" ],
    [ "Mail.cpp", "Mail_8cpp.html", null ],
    [ "Mail.h", "Mail_8h.html", [
      [ "Mail", "classMail.html", "classMail" ]
    ] ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "menu.cpp", "menu_8cpp.html", "menu_8cpp" ],
    [ "menu.h", "menu_8h.html", "menu_8h" ],
    [ "Network.cpp", "Network_8cpp.html", "Network_8cpp" ],
    [ "Network.h", "Network_8h.html", [
      [ "Network", "classNetwork.html", "classNetwork" ]
    ] ],
    [ "SubArea.cpp", "SubArea_8cpp.html", null ],
    [ "SubArea.h", "SubArea_8h.html", [
      [ "SubArea", "classSubArea.html", "classSubArea" ]
    ] ],
    [ "SummerSchool.cpp", "SummerSchool_8cpp.html", null ],
    [ "SummerSchool.h", "SummerSchool_8h.html", [
      [ "Trainer", "classTrainer.html", "classTrainer" ],
      [ "SummerSchool", "classSummerSchool.html", "classSummerSchool" ]
    ] ]
];