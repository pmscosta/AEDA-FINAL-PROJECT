var classNetwork =
[
    [ "Network", "classNetwork.html#a3cc2fb4f8fa4d507077e8da85ce5a1c8", null ],
    [ "Network", "classNetwork.html#a6c20a000b0a40b33b39b26874a4d50dd", null ],
    [ "~Network", "classNetwork.html#a7a4e19cdb4bf0c7ecf82baa643831492", null ],
    [ "addMail", "classNetwork.html#a848afdda14081f142404050833050d4b", null ],
    [ "getMails", "classNetwork.html#acd375ea0a8fb7558f15a432ce6354d93", null ],
    [ "setMails", "classNetwork.html#a2dfe751f83ea0ed37835baf23770d1b6", null ],
    [ "sortMails", "classNetwork.html#ab7eb46f37b172f7e7281ad5d27cb0ba0", null ],
    [ "mails", "classNetwork.html#a7d870918668129e7853c5374785955b1", null ]
];