var classConference =
[
    [ "Conference", "classConference.html#a433a85d640693398c2c96a2a655fc6f4", null ],
    [ "Conference", "classConference.html#a23b9a4644d1608f8f33400a6e41b32df", null ],
    [ "Conference", "classConference.html#ac86f5bff0837b92bccad09241a80137c", null ],
    [ "~Conference", "classConference.html#aad7fc5f411279abc70d4ff3c30d2bdd8", null ],
    [ "getEstimative", "classConference.html#a9d96f80eb37bdbf57bf318c8bd484e88", null ],
    [ "getSupport", "classConference.html#a6ca3f0f7b2714881dbc108ea7f08646f", null ],
    [ "getTrainers", "classConference.html#aae9e92d48205a80fa42e94564e3568c5", null ],
    [ "getType", "classConference.html#ad1cf07b29a4c4cc36483603ef9536186", null ],
    [ "showInfo", "classConference.html#a7a2f7b38c728f487d82356d3c671ef88", null ],
    [ "estimative", "classConference.html#ab3acc9b9aec3a4dbcfd18d1611337ecb", null ],
    [ "given_support", "classConference.html#a800a31bff9c492bc417cf8cecf450195", null ],
    [ "type", "classConference.html#af456d5097dc28808360f0d0fba2160c6", null ]
];