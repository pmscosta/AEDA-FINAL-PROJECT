var classNoSuchDate =
[
    [ "NoSuchDate", "classNoSuchDate.html#a0cad1c9e0d0a034a885b2529d6f79811", null ],
    [ "getDate", "classNoSuchDate.html#ad78fefa7d990af927c46096722a00f2c", null ],
    [ "date", "classNoSuchDate.html#af3b260da65ff8089d325b948e895f6b3", null ]
];